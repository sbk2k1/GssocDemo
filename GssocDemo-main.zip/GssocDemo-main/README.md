# GssocDemo
This is a demo repository for the workshop regarding open-source and GSSOC.
